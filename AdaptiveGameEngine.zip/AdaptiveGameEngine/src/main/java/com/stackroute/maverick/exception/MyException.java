package com.stackroute.maverick.exception;

@SuppressWarnings("serial")
public class MyException extends Exception {

	public MyException() {
		
		super();
	
	}

	public MyException(String msg) {
		
		super(msg);
		
	}

}
